# Safety Information 
 
## Why This Tool is Safe 
 
- **No internet connection required** 
- **No data sent anywhere** 
- **No account creation needed** 
- **No personal information collected** 
- **Works completely offline** 
- **Source code included for verification** 
 
## Safety Features 
 
- **Dry-run mode**: Preview changes without moving files 
- **Undo functionality**: Restore files to original locations 
- **Detailed logging**: Every action is recorded 
- **No file deletion**: Only moves files, never deletes 
